# Customer Shopping Behavior Analysis

## 1. Project Overview

This project analyzes customer shopping behavior using transactional data from **3,900 purchases** across multiple product categories. The goal is to understand spending patterns, customer segments, product preferences, and subscription behavior to support data-driven business decisions.

## 2. Dataset

- **Records:** 3,900
- **Columns:** 18
- **Missing data:** 37 values in the `review_rating` column
- **Key features:**
  - **Customer demographics:** Age, gender, location, subscription status
  - **Purchase details:** Item purchased, category, purchase amount, season, size, color
  - **Shopping behavior:** Discount applied, previous purchases, purchase frequency, review rating, shipping type
- **Dataset source:** `[Add the original dataset source or link]`

## 3. Tools & Technologies

- **Python:** Data loading, cleaning, feature engineering, and exploratory data analysis
- **Pandas:** Data manipulation and analysis
- **PostgreSQL:** Business analysis using SQL queries
- **Power BI:** Interactive dashboard and visual reporting

## 4. Project Workflow

1. **Load the data:** Imported the dataset into Python using Pandas.
2. **Explore the data:** Used `df.info()` and `df.describe()` to review the dataset structure and summary statistics.
3. **Handle missing values:** Imputed missing `review_rating` values using the median rating for each product category.
4. **Standardize columns:** Renamed columns to `snake_case` for readability.
5. **Create features:** Created `age_group` from customer ages and `purchase_frequency_days` from purchase data.
6. **Check consistency:** Checked whether `discount_applied` and `promo_code_used` contained redundant information and dropped `promo_code_used`.
7. **Load into PostgreSQL:** Connected Python to PostgreSQL and loaded the cleaned DataFrame.
8. **Analyze with SQL:** Queried the data to answer business questions.
9. **Visualize in Power BI:** Built an interactive dashboard to present insights visually.
10. **Recommend actions:** Used the analysis to suggest business improvements.

## 5. SQL Analysis

The PostgreSQL analysis explored these business questions:

1. **Revenue by gender:** Compared total revenue from male and female customers.
2. **High-spending discount users:** Identified customers who used discounts but spent above the average purchase amount.
3. **Top five products by rating:** Found products with the highest average review ratings.
4. **Shipping type comparison:** Compared average purchase amounts for Standard and Express shipping.
5. **Subscribers vs. non-subscribers:** Compared average spending and total revenue by subscription status.
6. **Discount-dependent products:** Identified five products with the highest percentage of discounted purchases.
7. **Customer segmentation:** Classified customers as New, Returning, or Loyal based on purchase history.
8. **Top three products per category:** Identified the most purchased products within each category.
9. **Repeat buyers and subscriptions:** Examined whether customers with more than five purchases were more likely to subscribe.
10. **Revenue by age group:** Calculated each age group's contribution to total revenue.

## 6. Power BI Dashboard

The dashboard includes KPI cards and visuals for subscription status, customer gender, shipping type, product category, purchase period, and location. Filters allow users to explore the displayed metrics by different customer and purchase attributes.

![Customer Behavior Dashboard](images/power-bi-dashboard.png)

**Key metrics visible in the dashboard screenshot:**
- **Number of customers:** 646
- **Average review rating:** 3.77
- **Average purchase amount:** $60.48

## 7. Business Recommendations

The project report proposes the following recommendations:

- **Boost subscriptions:** Promote exclusive benefits for subscribers.
- **Improve customer loyalty:** Reward repeat buyers and encourage them to become loyal customers.
- **Review discount policies:** Balance the potential sales benefits of discounts with margin control.
- **Improve product positioning:** Highlight top-rated and best-selling products in marketing campaigns.
- **Use targeted marketing:** Focus campaigns on high-revenue age groups and customers using express shipping.

## 8. Project Structure

```text
customer-shopping-behavior-analysis/
├── data/
│   └── customer_shopping_behavior.csv
├── notebooks/
│   └── customer_shopping_behavior_analysis.ipynb
├── sql/
│   └── customer_shopping_analysis.sql
├── images/
│   └── power-bi-dashboard.png
├── dashboard/
│   └── customer_shopping_dashboard.pbix
└── README.md
```

Update the example filenames above to match the files actually included in your repository. Do not commit passwords, database credentials, or other secrets.

## 9. How to Run

### Prerequisites

- Python
- Jupyter Notebook
- PostgreSQL
- Power BI Desktop

### Step 1: Clone the repository

```bash
git clone <your-github-repository-url>
cd customer-shopping-behavior-analysis
```

### Step 2: Install Python libraries

```bash
pip install pandas numpy jupyter sqlalchemy psycopg2-binary
```

### Step 3: Run the Python analysis

Open Jupyter Notebook and run the notebook cells in order to load, clean, and explore the dataset.

```bash
jupyter notebook
```

### Step 4: Run the SQL analysis

- Create a PostgreSQL database.
- Configure your database connection in the Python script or notebook.
- Load the cleaned dataset into PostgreSQL.
- Execute the SQL script in the `sql/` folder.

### Step 5: Open the Power BI dashboard

Open the `.pbix` file in Power BI Desktop. If prompted, configure the data source and refresh the data.

## 10. Results

The project produced a cleaned dataset, SQL analyses addressing ten shopping-related business questions, and an interactive Power BI dashboard. The dashboard screenshot displays **646 customers**, an **average review rating of 3.77**, and an **average purchase amount of $60.48**. The analysis was used to develop recommendations around subscriptions, customer loyalty, discount policy, product positioning, and targeted marketing.

## Author

**[Your Name]**

- LinkedIn: [Your LinkedIn URL]
- GitHub: [Your GitHub URL]
